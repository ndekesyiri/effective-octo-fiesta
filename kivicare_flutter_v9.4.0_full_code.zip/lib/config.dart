const APP_NAME = 'KiviCare';
const APP_FIRST_NAME = 'Kivi';
const APP_SECOND_NAME = 'Care';
const APP_NAME_TAG_LINE = 'Clinic and Patient Management App';

// LIVE
const DOMAIN_URL = '';

const BASE_URL = '$DOMAIN_URL/wp-json/';

const IQONIC_PACKAGE_NAME = "com.iqonic.kivicare"; // Do not change this Package Name.
const DEFAULT_LANGUAGE = 'en';
var COPY_RIGHT_TEXT = '© ${DateTime.now().year}. Made with ♡ by Iqonic Design';

const TERMS_AND_CONDITION_URL = '';
const PRIVACY_POLICY_URL = '';
const SUPPORT_URL = '';
const CODE_CANYON_URL = '';
const MAIL_TO = '';

const APPSTORE_APP_LINK='';

const STRIPE_CURRENCY_CODE = 'INR';
const STRIPE_MERCHANT_COUNTRY_CODE = 'IN';

const STRIPE_URL = 'https://api.stripe.com/v1/payment_intents';


// Pagination
const PER_PAGE = 20;
